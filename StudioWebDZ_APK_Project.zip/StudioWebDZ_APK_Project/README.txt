Studio Web DZ - Android APK project

النسخة مطورة وتحتوي على: عرض 30,000 دج، خدمات، أسئلة شائعة، نموذج طلب يفتح واتساب برسالة جاهزة، اتصال مباشر وبريد.

لإنشاء APK:
1) ارفع هذا المشروع إلى GitHub.
2) افتح Actions ثم Build Android APK.
3) شغّل workflow أو انتظر التشغيل بعد push.
4) من صفحة التشغيل حمّل Artifact باسم StudioWebDZ-debug-apk.

يمكن فتح المشروع أيضًا في Android Studio وبناء APK مباشرة.
